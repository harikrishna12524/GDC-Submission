#!/usr/bin/env bash

python3 task.py "$@"
