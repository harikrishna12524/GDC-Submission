import sys
from pathlib import Path
import os

new_path = os.getcwd()
# Comverting the txt acquired from the tasks.txt file to a usable dictionary
def txt_to_dist(txt):
    tasks = txt.split("\n")
    tasks_dict = {}
    if txt == "":
        return {}
    for task in tasks:
        task = [task.split(" ")[0], " ".join(task.split(" ")[1:]) ]
        #  If  two tasks have same proirity then they are assigned as values seperated by $-sign to the same key
        if task[0] in tasks_dict.keys():
            tasks_dict[task[0]] += "$" + task[1]
        else:
            tasks_dict[task[0]] = task[1]
            
    return tasks_dict

# converting dictionary back to txt to write in the file
def dist_to_txt(dicti):
    tasks = []
    for k in dicti.keys():
        if "$" in dicti[k]:
            temp = dicti[k].split("$")
            for tks in temp:
                tasks.append(F"{k} {tks}")
        else:
            tasks.append(F"{k} {dicti[k]}")

    return "\n".join(tasks)

def get_file_content(path):
    file = open(path, 'r')
    content = file.read()
    file.close()
    return content

def set_file_content(path, txt):
    file = open(path, 'w')
    file.write(txt)
    file.close
    return 1

def add_file_content(path, txt):
    file = open(path, 'a')
    file.write(txt)
    file.close
    return 1

def display_incomplete_tasks():
    tasks = get_file_content(task_file_path).split("\n")
    for k in range(len(tasks)):
        task = tasks[k].split(" ")
        print(F"{k + 1}. {' '.join(task[1:])} [{task[0]}]",end="\n")

def remove_task(tsk_ind):
    rmv_tsk = tasks.pop(tsk_indx - 1)
    set_file_content(task_file_path, "\n".join(tasks))

#def print(cont):
#    return cont

path = sys.argv[0]
arguments = sys.argv[1:]

current_location = path[:-7]
# Mentioning all the file paths
task_file_path = new_path+"task.txt"
completed_file_path = new_path+"completed.txt"

# Help menu printing
if arguments == [] or arguments==["help"]:
    print('Usage :-\n',end="")
    print('$ ./task add 2 hello world    # Add a new if Path(completed_file_path).is_file():',end="")

    print('$ ./task ls                   # Show incomplete priority list items sorted by priority in ascending order\n',end="")
    print('$ ./task del INDEX            # Delete the incomplete item with the given index\n',end="")
    print('$ ./task done INDEX           # Mark the incomplete item with the given index as complete\n',end="")
    print('$ ./task help                 # Show usage\n',end="")
    print('$ ./task report               # Statistics', end="")
elif arguments[0] == "add":
    local_args = arguments[1:]

    #Checking whether the command is complete

    if len(local_args) == 2:
        if not local_args[0].isnumeric():
            print("Error: Please Enter a Correct Format of Task")

        # Ensure non usage of $ in task decriptionif Path(completed_file_path).is_file():
                    
        elif "$" in local_args[1]:
            print("Error: Please Don't use '$' to describe task")


        else:
            # Checking if file exists
            if Path(task_file_path).is_file():

                tasks_txt = get_file_content(task_file_path)
                tasks = txt_to_dist(tasks_txt)
                tasks_list = tasks_txt.split("\n")
                
                if Path(completed_file_path).is_file():
                    comp_tasks = get_file_content(completed_file_path).split("\n")
                    if local_args[1] in  comp_tasks:
                        comp_tasks.remove(local_args[1])
                        set_file_content(completed_file_path, "\n".join(comp_tasks))
                    
                    
                if (local_args[0]+" "+local_args[1] not in tasks_list) or (local_args[1] not in [" ".join(k.split(" ")[1:]) for k in tasks_list]):
                    

                    # Adding in the new task
                    if local_args[0] in tasks.keys():
                        tasks[local_args[0]] += "$" + local_args[1]
                    else:
                        tasks[local_args[0]] = local_args[1]

                    print(tasks)

                    # Sorting the task Dictionary for proper arrangement
                    task_keys = list(map(str,sorted(list(map(int, tasks.keys())))))
                    tasks = {k:tasks[k] for k in task_keys}
                    

                    # adding new task set to file
                    tasks = dist_to_txt(tasks)
                    set_file_content(task_file_path, tasks)



            else:
                # if task.txt file doesn't exists
                add_file_content(task_file_path, local_args[0]+" "+local_args[1])

            print(F"""Added task: "{local_args[1]}" with priority {local_args[0]}""",end="")


#     For Imcomplete command
    elif len(local_args) == 1:
        if  local_args[0].isnumeric():
            print("Error: Missing tasks string. Nothing added!",end="")
        else:
            print("Error: Missing tasks string. Nothing added!",end="")

    elif len(local_args) == 0:
        print("Error: Missing tasks string. Nothing added!",end="")

# For Command ls - listing the incomplete tasks
elif arguments[0] == "ls":
    # If task.txt file exists
    if Path(task_file_path).is_file():
        # Retriving and displaying task.txt content
        display_incomplete_tasks()
    # if the file is not present
    else:
        tasks = []
        print("No tasks to display",end="")

# Program for Command to generate Report
elif arguments[0] == "report":
    if Path(task_file_path).is_file():
        tasks = get_file_content(task_file_path).split("\n")
        print(F"Pending : {len(tasks)}")
        if len(tasks)!=0:
            display_incomplete_tasks()
        else:
            print("There are no pending tasks!",end="")
    else:
        print("No tasks to display",end="")


    print("")
    if Path(completed_file_path).is_file():
                    
        comp_tasks = get_file_content(completed_file_path).split("\n")
        print(F"Completed : {len(comp_tasks)}")
        for k in range(len(comp_tasks)):
            print(F"{k+1}. {comp_tasks[k]}")

    else:
        comp_tasks = []
        print("No Task Completed",end="")

# Program for command done - marking a task done
elif arguments[0] == "done":
    local_args = arguments[1:]

    if len(local_args) == 1 and local_args[0].isnumeric():
        tsk_indx = int(local_args[0])
        if Path(task_file_path).is_file():
            tasks = get_file_content(task_file_path).split("\n")

            if len(tasks) >= tsk_indx and tsk_indx > 0:
                rmv_tsk = tasks.pop(tsk_indx-1)
                set_file_content(task_file_path, "\n".join(tasks))
                comp_tasks = []
                if Path(completed_file_path).is_file():
                    comp_tasks = get_file_content(completed_file_path).split("\n")
                if rmv_tsk.split(" ")[1:] not in comp_tasks :
                    add_file_content(completed_file_path, "\n"+" ".join(rmv_tsk.split(" ")[1:]))
                print("Marked item as done.",end="")
            else:
                print(F"Error: no incomplete item with index #{tsk_indx} exists.",end="")

    else:
        print("Error: Missing NUMBER for marking tasks as done.",end="")

elif arguments[0] == "del":
    local_args = arguments[1:]

    if len(local_args) == 1 and local_args[0].isnumeric():
        tsk_indx = int(local_args[0])
        if Path(task_file_path).is_file():
            tasks = get_file_content(task_file_path).split("\n")

            if len(tasks) >= tsk_indx and tsk_indx > 0:
                rmv_tsk = tasks.pop(tsk_indx - 1)
                set_file_content(task_file_path, "\n".join(tasks))
                print(F"Deleted task #{tsk_indx}",end="")

            else:
                # print(F"Error: task with index #0 does not exist. Nothing deleted.")
                print(F"Error: task with index #{tsk_indx} does not exist. Nothing deleted.",end="")

    else:
        print("Error: Missing NUMBER for deleting tasks.",end="")
